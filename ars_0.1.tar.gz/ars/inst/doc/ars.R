### R code from vignette source 'ars.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: compile-r-intro (eval = FALSE)
###################################################
## library(ars)
## 
## ## Std. Normal function 
## dnor <- function(x){
##   return((1/(sqrt(2*pi)))*exp(-(x^2)/2))
## }
## f = dnor
## adapt_sample <- ars(M = 10000, lb = -5, ub = 5, f)


